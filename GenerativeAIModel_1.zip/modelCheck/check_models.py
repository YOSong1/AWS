import boto3
from dotenv import load_dotenv
import os

# .env 파일에서 환경 변수 로드
load_dotenv()

aws_access_key = os.getenv('AWS_ACCESS_KEY_ID')
aws_secret_key = os.getenv('AWS_SECRET_ACCESS_KEY')
aws_region = os.getenv('AWS_DEFAULT_REGION', 'us-east-1')

# Bedrock 클라이언트 생성
bedrock = boto3.client(
    service_name='bedrock',
    region_name=aws_region,
    aws_access_key_id=aws_access_key,
    aws_secret_access_key=aws_secret_key
)

try:
    # 사용 가능한 모델 목록 조회
    response = bedrock.list_foundation_models()
    
    print("사용 가능한 Bedrock 모델들:")
    print("=" * 50)
    
    anthropic_models = []
    for model in response['modelSummaries']:
        if 'anthropic' in model['modelId'].lower():
            anthropic_models.append(model)
            print(f"* {model['modelId']}")
            print(f"   - 이름: {model.get('modelName', 'N/A')}")
            print(f"   - 상태: {model.get('modelLifecycleStatus', 'N/A')}")
            print(f"   - 입력 모달리티: {', '.join(model.get('inputModalities', []))}")
            print(f"   - 출력 모달리티: {', '.join(model.get('outputModalities', []))}")
            print()
    
    if anthropic_models:
        print(f"총 {len(anthropic_models)}개의 Anthropic 모델을 찾았습니다.")
    else:
        print("Anthropic 모델을 찾을 수 없습니다.")

except Exception as e:
    print(f"오류 발생: {e}")