import boto3
from dotenv import load_dotenv
import os
import json
from botocore.exceptions import ClientError
from pathlib import Path

# 상위 폴더의 .env 파일 로드
env_path = Path(__file__).parent.parent / '.env'
load_dotenv(env_path)

aws_access_key = os.getenv('AWS_ACCESS_KEY_ID')
aws_secret_key = os.getenv('AWS_SECRET_ACCESS_KEY')
aws_region = os.getenv('AWS_DEFAULT_REGION', 'us-east-1')

# Bedrock 클라이언트 생성
bedrock = boto3.client(
    service_name='bedrock',
    region_name=aws_region,
    verify=False,
    aws_access_key_id=aws_access_key,
    aws_secret_access_key=aws_secret_key
)

# Bedrock Runtime 클라이언트 (실제 호출용)
bedrock_runtime = boto3.client(
    service_name='bedrock-runtime',
    region_name=aws_region,
    verify=False,
    aws_access_key_id=aws_access_key,
    aws_secret_access_key=aws_secret_key
)


def test_model_with_converse(model_id: str) -> dict:
    """Converse API로 모델 테스트"""
    try:
        response = bedrock_runtime.converse(
            modelId=model_id,
            messages=[{"role": "user", "content": [{"text": "Hi"}]}],
            inferenceConfig={"maxTokens": 50}
        )
        return {"success": True, "method": "converse"}
    except ClientError as e:
        error_code = e.response.get("Error", {}).get("Code", "")
        return {"success": False, "method": "converse", "error": error_code}


def test_model_with_invoke(model_id: str) -> dict:
    """Invoke Model API로 모델 테스트 (Titan 등)"""
    try:
        # Titan 모델용 요청 형식
        body = json.dumps({
            "inputText": "Hi",
            "textGenerationConfig": {
                "maxTokenCount": 50,
                "temperature": 0.7
            }
        })
        
        response = bedrock_runtime.invoke_model(
            modelId=model_id,
            body=body,
            contentType="application/json",
            accept="application/json"
        )
        return {"success": True, "method": "invoke_model"}
    except ClientError as e:
        error_code = e.response.get("Error", {}).get("Code", "")
        return {"success": False, "method": "invoke_model", "error": error_code}


def test_model_availability(model_id: str) -> dict:
    """모델의 실제 사용 가능 여부 테스트"""
    # 먼저 Converse API 시도
    result = test_model_with_converse(model_id)
    if result["success"]:
        return result
    
    # Converse 실패 시 Invoke Model API 시도
    if result.get("error") != "AccessDeniedException":
        result = test_model_with_invoke(model_id)
    
    return result

try:
    # 사용 가능한 모델 목록 조회
    response = bedrock.list_foundation_models()
    
    print(f"리전: {aws_region}")
    print("=" * 80)
    print("실제 사용 가능한 모델 테스트 중...\n")
    
    tested_models = []
    working_models = []
    
    for model in response['modelSummaries']:
        model_id = model['modelId']
        model_name = model.get('modelName', 'N/A')
        provider = model.get('providerName', 'N/A')
        
        # 실제 API 호출 테스트 (모든 모델 테스트)
        print(f"🔍 테스트 중: {model_id}")
        test_result = test_model_availability(model_id)
        
        tested_models.append({
            'id': model_id,
            'name': model_name,
            'provider': provider,
            'result': test_result
        })
        
        if test_result['success']:
            working_models.append(model_id)
            print(f"   ✅ 사용 가능 ({test_result['method']})")
        else:
            error = test_result.get('error', 'Unknown')
            reason = ""
            if error == "AccessDeniedException":
                reason = " - AWS Console에서 승인 필요"
            elif error == "ValidationException":
                reason = " - 이 리전에서 미지원 또는 잘못된 모델 ID"
            elif error == "ThrottlingException":
                reason = " - API 호출 제한 (일시적)"
            print(f"   ❌ 사용 불가 - {error}{reason}")
        print()
    
    # 결과 요약
    print("=" * 80)
    print(f"\n📊 테스트 결과 요약:")
    print(f"   총 테스트: {len(tested_models)}개")
    print(f"   사용 가능: {len(working_models)}개\n")
    
    if working_models:
        print("✅ 즉시 사용 가능한 모델 목록:")
        for model_id in working_models:
            model_info = next(m for m in tested_models if m['id'] == model_id)
            print(f"   • {model_id}")
            print(f"     - 이름: {model_info['name']}")
            print(f"     - 제공업체: {model_info['provider']}")
            print(f"     - API: {model_info['result']['method']}")
            print()
        
        print("\n💡 bedrock_chat.py에서 사용하려면:")
        print(f'   MODEL_ID = "{working_models[0]}"  # Converse API용')
        print("   또는")
        print(f'   modelId="{working_models[0]}"  # invoke_model용')
    else:
        print("❌ 현재 리전에서 즉시 사용 가능한 모델이 없습니다.")
        print("   - Anthropic 모델은 AWS Console에서 승인 필요")
        print("   - 다른 리전(us-east-1, us-west-2)을 시도해보세요")

except Exception as e:
    print(f"오류 발생: {e}")