import os
import json
import sys

import boto3
from botocore.exceptions import NoCredentialsError, ClientError

try:
    # 1) .env가 있으면 자동으로 읽도록 시도 (없어도 무시)
    try:
        from dotenv import load_dotenv  # type: ignore
        load_dotenv()
    except Exception:
        pass

    # 2) 자격 증명 확인
    session = boto3.Session()
    creds = session.get_credentials()
    if creds is None:
        print("FAIL: 자격 증명을 찾지 못했습니다. (.env 또는 AWS CLI 'aws configure' 확인)")
        sys.exit(1)

    region = os.getenv("AWS_DEFAULT_REGION") or session.region_name or "us-east-1"
    print(f"OK: 자격 증명 로드 완료, region={region}")

    # 3) Bedrock 제어 플레인 접근 테스트 
    bedrock = boto3.client("bedrock", region_name=region)
    models = bedrock.list_foundation_models()
    total = len(models.get("modelSummaries", []))
    print(f"OK: Bedrock 연결 성공, 모델 수={total}")

    # 4) 선택적으로 아주 작은 추론 호출 (기본 비활성화)
    #    환경변수 QUICK_INFER=1 인 경우만 실행
    if os.getenv("QUICK_INFER") == "1":
        runtime = boto3.client("bedrock-runtime", region_name=region)
        body = {
            "inputText": "hello",
            "textGenerationConfig": {
                "maxTokenCount": 16,
                "temperature": 0.1,
                "topP": 0.9,
            },
        }
        resp = runtime.invoke_model(
            modelId="amazon.titan-text-express-v1",
            body=json.dumps(body),
            contentType="application/json",
            accept="application/json",
        )
        payload = json.loads(resp["body"].read())
        output_text = payload.get("results", [{}])[0].get("outputText")
        print("OK: 간단 추론 성공")
        print(output_text)

    print("SUCCESS: 환경 연동 확인 완료")
except NoCredentialsError:
    print("FAIL: AWS 자격 증명을 찾을 수 없습니다")
    sys.exit(1)
except ClientError as e:
    print(f"FAIL: AWS 클라이언트 오류: {e}")
    sys.exit(1)
except Exception as e:
    print(f"FAIL: 예상치 못한 오류: {e}")
    sys.exit(1)
