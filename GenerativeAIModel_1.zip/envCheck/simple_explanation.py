print("=== 이해하기 쉬운 설명 ===")
print()

import os
from pathlib import Path
from dotenv import load_dotenv

# .env 파일 경로 확인 및 로드
env_path = Path(__file__).parent.parent / '.env'  # 상위 폴더의 .env
print(f"[.env 파일 위치: {env_path}]")
print(f"[.env 파일 존재: {env_path.exists()}]\n")

print("1. 시스템 환경변수 확인 (load_dotenv 호출 전):")
try:
    # Python의 os.environ으로 직접 확인 (load_dotenv 호출 전)
    sys_aws_key = os.getenv('AWS_ACCESS_KEY_ID')
    sys_aws_secret = os.getenv('AWS_SECRET_ACCESS_KEY')
    sys_aws_region = os.getenv('AWS_DEFAULT_REGION')
    
    print(f"   AWS_ACCESS_KEY_ID: {'있음 (' + sys_aws_key[:10] + '...)' if sys_aws_key else '없음'}")
    print(f"   AWS_SECRET_ACCESS_KEY: {'있음' if sys_aws_secret else '없음'}")
    print(f"   AWS_DEFAULT_REGION: {sys_aws_region if sys_aws_region else '없음'}")
except Exception as e:
    print(f"   시스템 환경변수 확인 실패: {e}")

print("\n2. Python 프로세스 시작 시 (load_dotenv 호출 전):")
# os.getenv() 사용 - 기본값 지정 가능
aws_key_before = os.getenv('AWS_ACCESS_KEY_ID')
region_before = os.getenv('AWS_DEFAULT_REGION', 'ap-northeast-2')
print(f"   os.getenv('AWS_ACCESS_KEY_ID'): {aws_key_before[:10] + '...' if aws_key_before else '없음'}")
print(f"   os.getenv('AWS_DEFAULT_REGION', 'ap-northeast-2'): {region_before}")

print("\n3. load_dotenv() 호출 후:")
# 상위 폴더의 .env 파일 명시적으로 로드
load_dotenv(env_path)
aws_key = os.getenv('AWS_ACCESS_KEY_ID')
aws_secret = os.getenv('AWS_SECRET_ACCESS_KEY')
aws_region = os.getenv('AWS_DEFAULT_REGION', 'ap-northeast-2')

print(f"   os.getenv('AWS_ACCESS_KEY_ID'): {aws_key[:10] + '...' if aws_key else '없음'}")
print(f"   os.getenv('AWS_SECRET_ACCESS_KEY'): {'있음' if aws_secret else '없음'}")
print(f"   os.getenv('AWS_DEFAULT_REGION', 'ap-northeast-2'): {aws_region}")

print("\n핵심:")
print("- 시스템 환경변수에는 AWS 키가 없습니다")
print("- load_dotenv()가 .env 파일을 읽어서 Python의 os.environ에 임시로 추가합니다")
print("- 이는 현재 Python 프로세스에만 적용됩니다")
print("- Python 프로세스가 종료되면 이 환경변수들은 사라집니다")
print("- BedrockLLM은 현재 Python 프로세스의 os.environ에서 읽습니다")