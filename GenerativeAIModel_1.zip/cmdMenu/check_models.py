import boto3
from botocore.exceptions import ClientError

try:
    client = boto3.client('bedrock', region_name='us-east-1')
    response = client.list_foundation_models()
    
    print("=== Converse API 지원 모델 ===\n")
    for model in response.get('modelSummaries', []):
        inference_types = model.get('inferenceTypesSupported', [])
        if 'ON_DEMAND' in inference_types:
            model_id = model['modelId']
            model_name = model.get('modelName', 'N/A')
            print(f"{model_id}")
            print(f"  이름: {model_name}")
            print(f"  지원: {inference_types}")
            print()
            
except ClientError as e:
    print(f"오류: {e}")
