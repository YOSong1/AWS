import os
from functools import lru_cache
from dotenv import load_dotenv
import boto3
from botocore.exceptions import ClientError

load_dotenv()  # .env 로드 (없으면 무시)

# 리전 설정 (환경변수 우선)
REGION = os.getenv("AWS_DEFAULT_REGION") or os.getenv("AWS_REGION", "us-east-1")

# 프록시 및 SSL 설정
from botocore.config import Config
import warnings
from urllib3.exceptions import InsecureRequestWarning

warnings.filterwarnings('ignore', category=InsecureRequestWarning)

config = Config(
    proxies={},  # 프록시 사용 안 함
    proxies_config={'proxy_use_forwarding_for_https': False}
)

bedrock_runtime = boto3.client("bedrock-runtime", region_name=REGION, verify=False, config=config)
# 모델 메타 조회는 bedrock 서비스 클라이언트 사용
bedrock_control = boto3.client("bedrock", region_name=REGION, verify=False, config=config)


SYSTEM_PROMPT = os.getenv(
    "SYSTEM_PROMPT",
    "너는 한국어를 잘하는 시니어 백엔드 & 클라우드 개발자야. 짧고 명확하게 설명해줘.",
)


def get_available_models():
    """사용가능 모델 목록 반환. 환경변수 BEDROCK_CHAT_MODELS (comma 구분) 사용, 미설정 시 기본값.

    예: BEDROCK_CHAT_MODELS="amazon.titan-text-express-v1,amazon.nova-lite-v1,anthropic.claude-3-5-sonnet-20241022-v1:0"
    """
    env_val = os.getenv("BEDROCK_CHAT_MODELS")
    if env_val:
        return [m.strip() for m in env_val.split(",") if m.strip()]
    # 기본 제공 예시 (2025 시점 일부 - ap-northeast-2 리전 기준)
    return [
        "anthropic.claude-3-haiku-20240307-v1:0",
        "anthropic.claude-3-sonnet-20240229-v1:0",
        "anthropic.claude-3-5-sonnet-20240620-v1:0",
        "amazon.titan-text-lite-v1",
        "amazon.titan-text-express-v1",
    ]


@lru_cache(maxsize=1)
def _fetch_foundation_model_ids() -> set[str]:
    """Bedrock에서 사용 가능한 foundation modelId 집합 조회.
    실패 시 빈 set 반환 (네트워크/권한 이슈 등)."""
    try:
        # 페이지네이션 처리 (기본 pageSize 충분하면 단일 호출)
        resp = bedrock_control.list_foundation_models()
        models = resp.get("modelSummaries", [])
        return {m.get("modelId") for m in models if m.get("modelId")}
    except Exception:
        return set()


def is_valid_model_id(model_id: str) -> bool:
    model_id = model_id.strip()
    if not model_id:
        return False
    available = _fetch_foundation_model_ids()
    # 조회 실패한 경우에는 최소한 형식적(콜론 길이 등) 기본 검증만
    if not available:
        # 간단한 휴리스틱: 공백 없고 5글자 이상이면 임시 허용
        return " " not in model_id and len(model_id) >= 5
    return model_id in available


def ask_once(model_id: str, question: str) -> str:
    """지정한 model_id로 한 번 질문하고 답변 텍스트 반환"""
    try:
        combined = f"{SYSTEM_PROMPT}\n\n질문: {question}"
        response = bedrock_runtime.converse(
            modelId=model_id,
            messages=[{"role": "user", "content": [{"text": combined}]}],
            inferenceConfig={"maxTokens": 512, "temperature": 0.2, "topP": 0.9},
        )
        output_message = response["output"]["message"]
        parts = output_message.get("content", [])
        texts = [p.get("text", "") for p in parts if isinstance(p, dict)]
        return "".join(texts).strip()
    except ClientError as e:
        if "use case" in str(e).lower() or "Model use case details" in str(e):
            return (
                "모델 사용 승인(Use case details)이 필요합니다. 승인 불필요한 Amazon Titan으로 변경하거나 승인 후 재시도하세요."
            )
        raise


def choose_model_interactive() -> str | None:
    """모델 선택 인터랙티브. 선택 시 model_id 반환, 취소/종료 시 None."""
    models = get_available_models()
    print("\n=== 모델 선택 ===")
    for idx, m in enumerate(models, start=1):
        print(f"  {idx}. {m}")
    print("  0. 이전 메뉴로")
    while True:
        sel = input("번호 선택: ").strip()
        if sel == "0":
            return None
        if sel.isdigit():
            i = int(sel)
            if 1 <= i <= len(models):
                chosen = models[i - 1].strip()
                if not is_valid_model_id(chosen):
                    print("선택한 모델이 현재 리전/계정에서 유효하지 않습니다. 다른 모델을 선택하세요.")
                    continue
                return chosen
        print("잘못된 입력입니다. 다시 시도하세요.")


def chat_loop(model_id: str):
    """지정한 모델과 채팅. 'b' 입력 시 모델 재선택으로 복귀, 'q'/'quit' 질문 종료 후 모델 재선택, 'exit'/'종료' 전체 종료."""
    print(f"\n[채팅 시작] 모델: {model_id}")
    print("명령: b=모델 다시 선택 | q/quit=질문 종료 후 모델 재선택 | exit/종료=프로그램 종료")
    while True:
        q = input("\n> 질문: ").strip()
        lower = q.lower()
        if lower in ("b", "back"):
            # 모델 재선택으로 복귀
            print("채팅 종료. 모델 선택 메뉴로 돌아갑니다.")
            return "back"
        if lower in ("q", "quit"):
            # 질문 종료 후 모델 재선택
            print("질문을 종료합니다. 모델 선택 메뉴로 돌아갑니다.")
            return "back"
        if lower in ("exit", "종료"):
            return "exit"
        if not q:
            print("빈 질문은 무시합니다.")
            continue
        try:
            answer = ask_once(model_id, q)
            print("\n[모델 답변]")
            print(answer)
        except ClientError as e:
            error_code = e.response.get("Error", {}).get("Code", "Unknown")
            error_msg = e.response.get("Error", {}).get("Message", str(e))
            
            print(f"\n❌ Bedrock 호출 실패 [에러 코드: {error_code}]")
            print(f"메시지: {error_msg}")
            
            if "AccessDeniedException" in error_code or "access" in error_msg.lower():
                print("\n💡 모델 사용 권한이 없습니다. AWS Console에서 Model Access 승인이 필요합니다.")
            elif "ValidationException" in error_code:
                print(f"\n💡 모델 '{model_id}'이(가) 이 리전({REGION})에서 사용 불가능하거나 승인되지 않았습니다.")
            elif "ResourceNotFoundException" in error_code:
                print(f"\n💡 모델 '{model_id}'을(를) 찾을 수 없습니다. 모델 ID를 확인하세요.")
            
            print("다른 모델을 선택하려면 'b' 또는 'q'를 입력하세요.")
        except Exception as e:
            print(f"\n예상치 못한 오류: {type(e).__name__}: {str(e)}")


def main_menu():
    """최상위 메뉴: 1) 모델선택 2) 종료"""
    while True:
        print("\n========================")
        print("1. 모델선택")
        print("2. 종료")
        choice = input("메뉴 번호 입력: ").strip()
        if choice == "1":
            model_id = choose_model_interactive()
            if not model_id:
                continue  # 이전 메뉴로
            # 채팅 서브 메뉴 (내부에서 b 처리)
            result = chat_loop(model_id)
            if result == "exit":
                break
            # result == back 인 경우 루프 계속 (모델 재선택 가능)
        elif choice == "2" or choice.lower() in ("exit", "종료"):
            break
        else:
            print("잘못된 입력입니다.")
    print("프로그램을 종료합니다.")


if __name__ == "__main__":
    main_menu()
