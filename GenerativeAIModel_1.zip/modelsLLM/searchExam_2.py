import os
import json
import requests
from openai import OpenAI
from dotenv import load_dotenv

# 환경 변수 로드
load_dotenv()

# API 키들 설정
OPENAI_API_KEY = os.environ["OPENAI_API_KEY2"]
GOOGLE_API_KEY = os.environ["GOOGLE_API_KEY2"]
GOOGLE_CSE_ID = os.environ["GOOGLE_CSE_ID2"]


# OpenAI 클라이언트 생성
client = OpenAI(api_key=OPENAI_API_KEY)

def check_environment():
  
    print("=== 환경 설정 확인 ===")
    
    missing_keys = []
    
    # 각 API 키 확인
    if not OPENAI_API_KEY:
        missing_keys.append("OPENAI_API_KEY")
    else:
        print("OpenAI API 키: 설정됨", OPENAI_API_KEY)
    
    if not GOOGLE_API_KEY:
        missing_keys.append("GOOGLE_API_KEY")
    else:
        print("Google API 키: 설정됨", GOOGLE_API_KEY)
    
    if not GOOGLE_CSE_ID:
        missing_keys.append("GOOGLE_CSE_ID")
    else:
        print("Google Custom Search Engine ID: 설정됨", GOOGLE_CSE_ID)
    
    if missing_keys:
        print(f"누락된 환경 변수: {', '.join(missing_keys)}")
        return False
    
    print("모든 환경 변수가 설정되었습니다!")
    return True

def test_google_api():
    """
    Google Custom Search API 테스트 함수
    API가 정상적으로 작동하는지 확인
    """
    print("\n=== Google API 테스트 ===")
    
    # 테스트용 검색 파라미터
    test_params = {
        "key": GOOGLE_API_KEY,
        "cx": GOOGLE_CSE_ID,
        "q": "test",
        "num": 1
    }
    
    try:
        # Google Custom Search API 호출
        response = requests.get("https://www.googleapis.com/customsearch/v1", params=test_params,timeout=10 )
        
        print(f"응답 상태 코드: {response.status_code}")
        
        if response.status_code == 200:
            data = response.json()
            print("Google API 테스트 성공!")
            print(f"검색 결과 수: {len(data.get('items', []))}")
            return True
        else:
            print(f"API 오류: {response.status_code}")
            try:
                error_data = response.json()
                print(f"오류 상세: {json.dumps(error_data, indent=2, ensure_ascii=False)}")
            except:
                print(f"응답 내용: {response.text[:500]}")
            return False
            
    except Exception as e:
        print(f"테스트 중 오류: {e}")
        return False

def test_openai_api():

    print("\n=== OpenAI API 테스트 ===")
    
    try:
        response = client.chat.completions.create(
            model="gpt-4o",
            messages=[{"role": "user", "content": "안녕하세요. 간단한 테스트입니다."}],
            max_tokens=50
        )
        
        answer = response.choices[0].message.content.strip()
        print("OpenAI API 테스트 성공!")
        print(f"테스트 응답: {answer}")
        return True
        
    except Exception as e:
        print(f"OpenAI API 테스트 실패: {e}")
        return False




if not check_environment():
    print("\n해결 방법:")
    print("1. .env 파일에 필요한 API 키들을 설정하세요")
    print("2. Google Cloud Console에서 Custom Search API를 활성화하세요")
    print("3. Google Programmable Search Engine을 생성하세요")
    exit()


if not test_google_api():
    print("\nGoogle API 문제 해결:")
    print("1. Google Cloud Console에서 'Custom Search API' 활성화")
    print("2. API 키 제한 설정 확인 (애플리케이션 제한, API 제한)")
    print("3. 결제 계정 연결 확인")
    exit()


