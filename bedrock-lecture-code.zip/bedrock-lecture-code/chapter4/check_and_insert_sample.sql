-- 1. 현재 스키마 확인
SELECT schema_name FROM information_schema.schemata WHERE schema_name = 'bedrock_integration';

-- 2. 테이블 존재 확인
SELECT table_name FROM information_schema.tables WHERE table_schema = 'bedrock_integration';

-- 3. 테이블 구조 확인
SELECT column_name, data_type, character_maximum_length 
FROM information_schema.columns 
WHERE table_schema = 'bedrock_integration' AND table_name = 'bedrock_kb';

-- 4. 현재 데이터 개수 확인
SELECT COUNT(*) FROM bedrock_integration.bedrock_kb;

-- 5. 인덱스 확인
SELECT indexname, indexdef 
FROM pg_indexes 
WHERE schemaname = 'bedrock_integration' AND tablename = 'bedrock_kb';

-- 6. 샘플 데이터 삽입 (1024차원 벡터 - Titan Embedding V2용)
INSERT INTO bedrock_integration.bedrock_kb (id, embedding, chunks, metadata)
VALUES 
(
    gen_random_uuid(),
    array_fill(0.1, ARRAY[1024])::vector(1024),
    'Amazon Bedrock은 AI21 Labs, Anthropic, Cohere, Meta, Stability AI, Amazon의 기초 모델(FM)을 단일 API로 제공하는 완전관리형 서비스입니다.',
    '{"source": "aws_docs", "category": "bedrock_intro", "created_at": "2024-01-01"}'::json
),
(
    gen_random_uuid(),
    array_fill(0.2, ARRAY[1024])::vector(1024),
    'Amazon Titan Embeddings는 텍스트를 수치 표현으로 변환하여 검색, 개인화 및 클러스터링과 같은 사용 사례에 유용합니다.',
    '{"source": "aws_docs", "category": "titan_embedding", "created_at": "2024-01-02"}'::json
),
(
    gen_random_uuid(),
    array_fill(0.3, ARRAY[1024])::vector(1024),
    'RAG(Retrieval-Augmented Generation)는 외부 지식 베이스를 활용하여 LLM의 응답 품질을 향상시키는 기술입니다.',
    '{"source": "technical_docs", "category": "rag_concept", "created_at": "2024-01-03"}'::json
);

-- 7. 삽입된 데이터 확인
SELECT id, chunks, metadata FROM bedrock_integration.bedrock_kb;

-- 8. 벡터 유사도 검색 테스트 (샘플 벡터와 가장 유사한 항목 찾기)
SELECT id, chunks, metadata, 
       embedding <=> array_fill(0.15, ARRAY[1024])::vector(1024) AS distance
FROM bedrock_integration.bedrock_kb
ORDER BY distance
LIMIT 3;
