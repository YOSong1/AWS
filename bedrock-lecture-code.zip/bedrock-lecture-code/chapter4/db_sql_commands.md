# PostgreSQL DB 관리 SQL 명령어 모음

## 1. DB 접속 방법 (CloudShell)

```bash
# psql 클라이언트로 접속
psql -h mydb-1.ckjwoek02fc7.us-east-1.rds.amazonaws.com -U song -d ragdb -p 5432

# 비밀번호 입력: ehdehddl1!
```

## 2. 기본 메타 명령어 (psql 내부)

```sql
-- 현재 데이터베이스 확인
SELECT current_database();

-- 접속된 사용자 확인
SELECT current_user;

-- 데이터베이스 목록 보기
\l

-- 현재 DB의 스키마 목록
\dn

-- 스키마별 테이블 목록
\dt
\dt bedrock_integration.*

-- 테이블 구조 확인
\d bedrock_integration.bedrock_kb
\d langchain_pg_collection
\d langchain_pg_embedding

-- 종료
\q
```

## 3. 스키마 및 테이블 조회

### 3.1 스키마 목록 확인
```sql
SELECT schema_name 
FROM information_schema.schemata 
ORDER BY schema_name;
```

### 3.2 특정 스키마의 테이블 목록
```sql
-- bedrock_integration 스키마의 테이블
SELECT table_name 
FROM information_schema.tables 
WHERE table_schema = 'bedrock_integration';

-- public 스키마의 테이블 (LangChain이 사용)
SELECT table_name 
FROM information_schema.tables 
WHERE table_schema = 'public';
```

### 3.3 모든 테이블 목록 (스키마 포함)
```sql
SELECT 
    table_schema,
    table_name,
    table_type
FROM information_schema.tables 
WHERE table_schema NOT IN ('pg_catalog', 'information_schema')
ORDER BY table_schema, table_name;
```

## 4. 테이블 구조 확인

### 4.1 컬럼 정보
```sql
SELECT 
    column_name,
    data_type,
    character_maximum_length,
    is_nullable
FROM information_schema.columns 
WHERE table_schema = 'bedrock_integration' 
  AND table_name = 'bedrock_kb'
ORDER BY ordinal_position;
```

### 4.2 인덱스 확인
```sql
SELECT 
    indexname,
    indexdef 
FROM pg_indexes 
WHERE schemaname = 'bedrock_integration' 
  AND tablename = 'bedrock_kb';
```

### 4.3 테이블 크기 확인
```sql
SELECT 
    schemaname,
    tablename,
    pg_size_pretty(pg_total_relation_size(schemaname||'.'||tablename)) AS size
FROM pg_tables 
WHERE schemaname NOT IN ('pg_catalog', 'information_schema')
ORDER BY pg_total_relation_size(schemaname||'.'||tablename) DESC;
```

## 5. 데이터 조회 (SELECT)

### 5.1 bedrock_integration.bedrock_kb 테이블
```sql
-- 전체 데이터 개수
SELECT COUNT(*) FROM bedrock_integration.bedrock_kb;

-- 전체 데이터 조회 (벡터 제외)
SELECT id, chunks, metadata 
FROM bedrock_integration.bedrock_kb;

-- 처음 5개만 조회
SELECT id, chunks, metadata 
FROM bedrock_integration.bedrock_kb 
LIMIT 5;

-- 특정 조건으로 조회
SELECT id, chunks, metadata 
FROM bedrock_integration.bedrock_kb 
WHERE metadata->>'category' = 'bedrock_intro';

-- 벡터 차원 확인
SELECT id, array_length(embedding, 1) as vector_dimension
FROM bedrock_integration.bedrock_kb
LIMIT 1;
```

### 5.2 LangChain 테이블 (aws_vector collection)
```sql
-- Collection 목록
SELECT * FROM langchain_pg_collection;

-- 임베딩 데이터 조회 (벡터 제외)
SELECT 
    id,
    collection_id,
    document,
    cmetadata
FROM langchain_pg_embedding
LIMIT 10;

-- 특정 collection의 데이터 개수
SELECT COUNT(*) 
FROM langchain_pg_embedding e
JOIN langchain_pg_collection c ON e.collection_id = c.uuid
WHERE c.name = 'aws_vector';

-- Collection별 문서 개수
SELECT 
    c.name as collection_name,
    COUNT(e.id) as document_count
FROM langchain_pg_collection c
LEFT JOIN langchain_pg_embedding e ON c.uuid = e.collection_id
GROUP BY c.name;
```

## 6. 벡터 검색 (유사도 검색)

### 6.1 코사인 유사도 검색
```sql
-- 샘플 벡터와 유사한 문서 찾기 (거리가 가까울수록 유사)
SELECT 
    id,
    chunks,
    metadata,
    embedding <=> '[0.1, 0.1, ...]'::vector AS distance
FROM bedrock_integration.bedrock_kb
ORDER BY distance
LIMIT 5;
```

### 6.2 내적(Inner Product) 검색
```sql
SELECT 
    id,
    chunks,
    (embedding <#> '[0.1, 0.1, ...]'::vector) * -1 AS similarity
FROM bedrock_integration.bedrock_kb
ORDER BY similarity DESC
LIMIT 5;
```

## 7. 데이터 삽입/수정/삭제

### 7.1 데이터 삽입
```sql
-- UUID 생성 함수 필요 (gen_random_uuid())
INSERT INTO bedrock_integration.bedrock_kb (id, embedding, chunks, metadata)
VALUES (
    gen_random_uuid(),
    array_fill(0.5, ARRAY[1024])::vector(1024),
    '테스트 문서입니다.',
    '{"source": "manual", "type": "test"}'::json
);
```

### 7.2 데이터 수정
```sql
-- 특정 ID의 메타데이터 수정
UPDATE bedrock_integration.bedrock_kb
SET metadata = '{"source": "updated", "type": "test"}'::json
WHERE id = 'your-uuid-here';

-- chunks 내용 수정
UPDATE bedrock_integration.bedrock_kb
SET chunks = '수정된 내용입니다.'
WHERE metadata->>'category' = 'test';
```

### 7.3 데이터 삭제
```sql
-- 특정 ID 삭제
DELETE FROM bedrock_integration.bedrock_kb
WHERE id = 'your-uuid-here';

-- 특정 조건으로 삭제
DELETE FROM bedrock_integration.bedrock_kb
WHERE metadata->>'source' = 'manual';

-- 전체 삭제 (주의!)
TRUNCATE TABLE bedrock_integration.bedrock_kb;
```

## 8. Extension 및 시스템 정보

### 8.1 설치된 Extension 확인
```sql
-- pgvector extension 확인
SELECT extname, extversion 
FROM pg_extension 
WHERE extname = 'vector';

-- 모든 extension 확인
SELECT extname, extversion 
FROM pg_extension;
```

### 8.2 데이터베이스 통계
```sql
-- 데이터베이스 크기
SELECT pg_size_pretty(pg_database_size(current_database()));

-- 테이블별 row 수
SELECT 
    schemaname,
    tablename,
    n_live_tup as row_count
FROM pg_stat_user_tables
ORDER BY n_live_tup DESC;
```

## 9. 권한 관리

### 9.1 현재 사용자 권한 확인
```sql
-- 테이블 권한 확인
SELECT 
    grantee,
    privilege_type
FROM information_schema.table_privileges
WHERE table_schema = 'bedrock_integration' 
  AND table_name = 'bedrock_kb';
```

### 9.2 스키마 권한 확인
```sql
SELECT 
    schema_name,
    schema_owner
FROM information_schema.schemata
WHERE schema_name = 'bedrock_integration';
```

## 10. 유용한 집계 쿼리

### 10.1 메타데이터 분석
```sql
-- category별 문서 개수
SELECT 
    metadata->>'category' as category,
    COUNT(*) as count
FROM bedrock_integration.bedrock_kb
GROUP BY metadata->>'category'
ORDER BY count DESC;

-- source별 문서 개수
SELECT 
    metadata->>'source' as source,
    COUNT(*) as count
FROM bedrock_integration.bedrock_kb
GROUP BY metadata->>'source';
```

### 10.2 최근 데이터 조회
```sql
-- 메타데이터의 created_at 기준 최근 문서
SELECT 
    id,
    chunks,
    metadata->>'created_at' as created_at
FROM bedrock_integration.bedrock_kb
ORDER BY metadata->>'created_at' DESC
LIMIT 10;
```

## 11. 트랜잭션 관리

```sql
-- 트랜잭션 시작
BEGIN;

-- 작업 수행
INSERT INTO bedrock_integration.bedrock_kb ...;
UPDATE bedrock_integration.bedrock_kb ...;

-- 커밋 (확정)
COMMIT;

-- 또는 롤백 (취소)
ROLLBACK;
```

## 12. 백업 및 복원 (CloudShell)

```bash
# 전체 데이터베이스 백업
pg_dump -h mydb-1.ckjwoek02fc7.us-east-1.rds.amazonaws.com \
        -U song -d ragdb > backup.sql

# 특정 테이블만 백업
pg_dump -h mydb-1.ckjwoek02fc7.us-east-1.rds.amazonaws.com \
        -U song -d ragdb \
        -t bedrock_integration.bedrock_kb > bedrock_kb_backup.sql

# 복원
psql -h mydb-1.ckjwoek02fc7.us-east-1.rds.amazonaws.com \
     -U song -d ragdb < backup.sql
```

## 13. 자주 사용하는 조합 쿼리

### 13.1 빈 테이블 확인
```sql
SELECT 
    schemaname,
    tablename,
    n_live_tup as row_count
FROM pg_stat_user_tables
WHERE n_live_tup = 0
ORDER BY schemaname, tablename;
```

### 13.2 LangChain과 bedrock_integration 비교
```sql
-- 두 시스템의 문서 개수 비교
SELECT 
    'bedrock_integration.bedrock_kb' as table_name,
    COUNT(*) as count
FROM bedrock_integration.bedrock_kb
UNION ALL
SELECT 
    'langchain (aws_vector)',
    COUNT(*)
FROM langchain_pg_embedding e
JOIN langchain_pg_collection c ON e.collection_id = c.uuid
WHERE c.name = 'aws_vector';
```


