import boto3
import json

# Bedrock Agent Runtime 클라이언트 생성
bedrock_agent_runtime = boto3.client(
    service_name="bedrock-agent-runtime",
    region_name="us-east-1"  # 본인의 Knowledge Base 리전으로 변경
)

def retrieve_and_generate(query, kbId):
    """Knowledge Base에서 검색하고 Claude로 답변 생성"""
    # 리전을 us-east-1로 통일 (클라이언트와 동일하게)
    modelArn = 'arn:aws:bedrock:us-east-1::foundation-model/anthropic.claude-3-5-sonnet-20240620-v1:0'
    
    return bedrock_agent_runtime.retrieve_and_generate(
        input={
            'text': query,
        },
        retrieveAndGenerateConfiguration={
            'type': 'KNOWLEDGE_BASE',
            'knowledgeBaseConfiguration': {
                'knowledgeBaseId': kbId,
                'modelArn': modelArn,
            }
        }
    )

# Lambda 함수 (원본)
def lambda_handler(event, context):
    response = retrieve_and_generate("중대재해처벌법의 대상이 누구인가요?", "{KnowledgeBaseID}")
    output = response["output"]
    citations = response["citations"]
    
    return output

# 로컬 실행용 코드
if __name__ == "__main__":
    # 실제 Knowledge Base ID로 교체 필요
    # AWS Console -> Bedrock -> Knowledge bases에서 확인
    KB_ID = "XXXXXXX"  # 예: "ABCDEFGHIJ"
    
    print("=" * 60)
    print("Knowledge Base RAG 테스트 (4-9.py)")
    print("검색 + Claude 답변 생성")
    print("=" * 60)
    
    query = "음악 교과목에서 생성형 AI의 역할은?"
    print(f"\n질문: {query}")
    print("\n처리 중 (검색 + 답변 생성)...")
    
    try:
        response = retrieve_and_generate(query, KB_ID)
        
        # 생성된 답변
        output = response["output"]["text"]
        print("\n" + "=" * 60)
        print("생성된 답변:")
        print("=" * 60)
        print(output)
        
        # 출처 (Citations)
        citations = response.get("citations", [])
        if citations:
            print("\n" + "=" * 60)
            print(f"참조한 문서: {len(citations)}개")
            print("=" * 60)
            
            for idx, citation in enumerate(citations, 1):
                print(f"\n[출처 {idx}]")
                
                # 참조된 텍스트
                if "retrievedReferences" in citation:
                    for ref_idx, ref in enumerate(citation["retrievedReferences"], 1):
                        content = ref["content"]["text"]
                        print(f"  내용: {content[:150]}...")
                        
                        # S3 위치
                        if "location" in ref:
                            location = ref["location"]
                            if "s3Location" in location:
                                s3_uri = location["s3Location"]["uri"]
                                print(f"  출처: {s3_uri}")
                        print()
        
        print("=" * 60)
        
    except Exception as e:
        print(f"\n오류 발생: {e}")
        print("\n필요한 설정:")
        print("1. KB_ID를 실제 Knowledge Base ID로 변경")
        print("2. AWS 자격증명 설정 확인 (aws configure)")
        print("3. Knowledge Base가 존재하고 접근 권한이 있는지 확인")
        print("4. Claude 모델 접근 권한 확인")
