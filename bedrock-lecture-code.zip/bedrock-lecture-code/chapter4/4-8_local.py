import boto3
import json

# Bedrock Agent Runtime 클라이언트 생성
bedrock_agent_runtime = boto3.client(
    service_name="bedrock-agent-runtime",
    region_name="us-east-1"  # 본인의 Knowledge Base 리전으로 변경
)

def retrieve(query, kbId, numberOfResults=5):
    """Knowledge Base에서 관련 문서 검색 (답변 생성 없음)"""
    return bedrock_agent_runtime.retrieve(
        retrievalQuery={
            'text': query
        },
        knowledgeBaseId=kbId,
        retrievalConfiguration={
            'vectorSearchConfiguration': {
                'numberOfResults': numberOfResults
            }
        }
    )

# Lambda 함수 (원본)
def lambda_handler(event, context):
    response = retrieve("수학에서 생성형 AI 역할?", "{KnowledgeBaseID}")
    results = response["retrievalResults"]
    return results

# 로컬 실행용 코드
if __name__ == "__main__":
    # 실제 Knowledge Base ID로 교체 필요
    # AWS Console -> Bedrock -> Knowledge bases에서 확인
    KB_ID = "XXXXXXX"  # 예: "ABCDEFGHIJ"
    
    print("=" * 60)
    print("Knowledge Base 검색 테스트 (4-8.py)")
    print("=" * 60)
    
    query = "누구를 대상으로 하는 교육 내용인가?"
    print(f"\n질문: {query}")
    print("\n검색 중...")
    
    try:
        response = retrieve(query, KB_ID, numberOfResults=3)
        results = response["retrievalResults"]
        
        print(f"\n검색된 문서 개수: {len(results)}개")
        print("\n" + "=" * 60)
        
        for idx, result in enumerate(results, 1):
            print(f"\n[문서 {idx}]")
            print(f"점수: {result['score']:.4f}")
            print(f"내용: {result['content']['text'][:200]}...")
            
            # 메타데이터 (S3 위치 등)
            if 'location' in result:
                location = result['location']
                if 's3Location' in location:
                    s3_uri = location['s3Location']['uri']
                    print(f"출처: {s3_uri}")
            print("-" * 60)
            
    except Exception as e:
        print(f"\n오류 발생: {e}")
        print("\n문제 해결 방법:")
        print("1. 데이터 소스 동기화 필수!")
        print("   AWS Console → Bedrock → Knowledge bases")
        print("   → 데이터 소스 선택 → '동기화' 버튼 클릭")
        print("\n2. S3에 파일이 올바르게 업로드되었는지 확인")
        print("3. PDF가 텍스트 추출 가능한 형식인지 확인")
        print("4. Knowledge Base와 코드의 리전이 일치하는지 확인")
        print("5. AWS 자격증명 설정 확인 (aws configure)")
