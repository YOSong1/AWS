import psycopg
import uuid
import json

# DB 연결 정보 (본인의 정보로 수정)
connection_string = "postgresql+psycopg://song:xxxxxxx.us-east-1.rds.amazonaws.com:5432/ragdb"

# 샘플 데이터
sample_data = [
    {
        "chunks": "Amazon Bedrock은 AI21 Labs, Anthropic, Cohere, Meta, Stability AI, Amazon의 기초 모델(FM)을 단일 API로 제공하는 완전관리형 서비스입니다.",
        "metadata": {"source": "aws_docs", "category": "bedrock_intro", "created_at": "2024-01-01"}
    },
    {
        "chunks": "Amazon Titan Embeddings는 텍스트를 수치 표현으로 변환하여 검색, 개인화 및 클러스터링과 같은 사용 사례에 유용합니다.",
        "metadata": {"source": "aws_docs", "category": "titan_embedding", "created_at": "2024-01-02"}
    },
    {
        "chunks": "RAG(Retrieval-Augmented Generation)는 외부 지식 베이스를 활용하여 LLM의 응답 품질을 향상시키는 기술입니다.",
        "metadata": {"source": "technical_docs", "category": "rag_concept", "created_at": "2024-01-03"}
    }
]

try:
    with psycopg.connect(connection_string) as conn:
        with conn.cursor() as cur:
            print("샘플 데이터 삽입 중...")
            
            for idx, data in enumerate(sample_data, 1):
                # UUID 생성
                record_id = uuid.uuid4()
                
                # 1024차원 더미 벡터 생성 (실제로는 Bedrock Embeddings 사용)
                embedding_value = f"[{','.join(['0.1'] * 1024)}]"
                
                # 데이터 삽입
                cur.execute("""
                    INSERT INTO bedrock_integration.bedrock_kb (id, embedding, chunks, metadata)
                    VALUES (%s, %s::vector, %s, %s)
                """, (
                    str(record_id),
                    embedding_value,
                    data["chunks"],
                    json.dumps(data["metadata"])
                ))
                
                print(f"  [{idx}] 삽입 완료: {data['chunks'][:50]}...")
            
            conn.commit()
            print("\n모든 샘플 데이터 삽입 완료!")
            
            # 삽입된 데이터 확인
            print("\n=== 삽입된 데이터 확인 ===")
            cur.execute("SELECT COUNT(*) FROM bedrock_integration.bedrock_kb")
            count = cur.fetchone()[0]
            print(f"총 {count}개의 레코드")
            
except Exception as e:
    print(f"오류 발생: {e}")
