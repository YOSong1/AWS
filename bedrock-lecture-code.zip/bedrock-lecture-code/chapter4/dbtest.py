import psycopg2
from pgvector.psycopg2 import register_vector


endpoint = "mydb-1.xxxxxx.us-east-1.rds.amazonaws.com"
username = "your name"
password = "your password"
database = "db name"


# DB 연결
conn = psycopg2.connect(
    host=endpoint,
    database=database,
    user=username,
    password=password,
    port=5432
)

# pgvector 확장 등록
register_vector(conn)

# 커서 생성
cur = conn.cursor()

# 연결 테스트
cur.execute("SELECT version();")
db_version = cur.fetchone()
print(f"PostgreSQL 버전: {db_version[0]}")

# vector 확장 확인
cur.execute("SELECT extversion FROM pg_extension WHERE extname='vector';")
vector_version = cur.fetchone()
if vector_version:
    print(f"pgvector 버전: {vector_version[0]}")
else:
    print("pgvector 확장이 설치되지 않았습니다.")

print("\nDB 연결 성공!")

# 연결 종료
cur.close()
conn.close()