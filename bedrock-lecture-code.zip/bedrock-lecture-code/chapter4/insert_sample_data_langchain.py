from langchain_aws import BedrockEmbeddings
from langchain_community.vectorstores import PGVector
from langchain_core.documents import Document

# DB 연결 정보 (SQLAlchemy 형식 - LangChain용)
connection_string = "postgresql+psycopg://song:xxxxxxx.us-east-1.rds.amazonaws.com:5432/ragdb"
collection_name = "aws_vector"

# Bedrock Embeddings 초기화
print("Bedrock Embeddings 모델 로딩 중...")
embeddings = BedrockEmbeddings(
    model_id="amazon.titan-embed-text-v2:0"
)

# 샘플 데이터 - LangChain Document 형식으로 생성
sample_documents = [
    Document(
        page_content="Amazon Bedrock은 AI21 Labs, Anthropic, Cohere, Meta, Stability AI, Amazon의 기초 모델(FM)을 단일 API로 제공하는 완전관리형 서비스입니다.",
        metadata={"source": "aws_docs", "category": "bedrock_intro", "created_at": "2024-01-01"}
    ),
    Document(
        page_content="Amazon Titan Embeddings는 텍스트를 수치 표현으로 변환하여 검색, 개인화 및 클러스터링과 같은 사용 사례에 유용합니다.",
        metadata={"source": "aws_docs", "category": "titan_embedding", "created_at": "2024-01-02"}
    ),
    Document(
        page_content="RAG(Retrieval-Augmented Generation)는 외부 지식 베이스를 활용하여 LLM의 응답 품질을 향상시키는 기술입니다.",
        metadata={"source": "technical_docs", "category": "rag_concept", "created_at": "2024-01-03"}
    ),
    Document(
        page_content="Titan Embedding V2는 1024차원의 벡터를 생성하며, 텍스트 유사도 검색에 최적화되어 있습니다.",
        metadata={"source": "aws_docs", "category": "titan_specs", "created_at": "2024-01-04"}
    ),
    Document(
        page_content="Claude 3.5 Sonnet은 복잡한 추론과 코딩 작업에 뛰어난 성능을 보이는 Anthropic의 최신 모델입니다.",
        metadata={"source": "anthropic_docs", "category": "claude_model", "created_at": "2024-01-05"}
    )
]

try:
    print(f"\n샘플 데이터 {len(sample_documents)}개를 벡터 DB에 삽입 중...")
    print("(Bedrock API를 통해 임베딩 생성 중...)")
    
    # PGVector를 사용하여 문서 삽입
    # from_documents는 자동으로 임베딩을 생성하고 DB에 저장
    vectordb = PGVector.from_documents(
        documents=sample_documents,
        embedding=embeddings,
        connection_string=connection_string,
        collection_name=collection_name,
        use_jsonb=True,
    )
    
    print("\n모든 샘플 데이터 삽입 완료!")
    print(f"  - Collection: {collection_name}")
    print(f"  - 삽입된 문서: {len(sample_documents)}개")
    print(f"  - 임베딩 차원: 1024 (Titan Embed Text V2)")
    
    # 삽입된 데이터로 간단한 검색 테스트
    print("\n=== 유사도 검색 테스트 ===")
    query = "Bedrock이란 무엇인가요?"
    print(f"질문: {query}")
    
    results = vectordb.similarity_search(query, k=2)
    print(f"\n가장 유사한 {len(results)}개 문서:")
    for idx, doc in enumerate(results, 1):
        print(f"\n  [{idx}] {doc.page_content[:80]}...")
        print(f"      메타데이터: {doc.metadata}")
    
except Exception as e:
    print(f"\n오류 발생: {e}")
    import traceback
    traceback.print_exc()
