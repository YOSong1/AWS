import psycopg2

endpoint = "mydb-1.xxxxxx.us-east-1.rds.amazonaws.com"
username = "your name"
password = "your password"
database = "db name"

print("pgvector 확장을 설치합니다...\n")

try:
    # DB 연결
    conn = psycopg2.connect(
        host=endpoint,
        database=database,
        user=username,
        password=password,
        port=5432
    )
    conn.autocommit = True
    
    cur = conn.cursor()
    
    # pgvector 확장 생성
    print("1. pgvector 확장 생성 중...")
    cur.execute("CREATE EXTENSION IF NOT EXISTS vector;")
    print("pgvector 확장이 생성되었습니다.")
    
    # 확장 버전 확인
    cur.execute("SELECT extversion FROM pg_extension WHERE extname='vector';")
    vector_version = cur.fetchone()
    if vector_version:
        print(f"pgvector 버전: {vector_version[0]}")
    
    # PostgreSQL 버전 확인
    cur.execute("SELECT version();")
    db_version = cur.fetchone()
    print(f"\n2. PostgreSQL 버전: {db_version[0]}")
    
    print("\npgvector 설치 완료!")
    
    cur.close()
    conn.close()
    
except Exception as e:
    print(f"오류 발생: {e}")
