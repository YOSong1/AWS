import psycopg2
from psycopg2 import sql

endpoint = "mydb-1.xxxxxx.us-east-1.rds.amazonaws.com"
username = "your name"
password = "your password"

# 먼저 postgres 데이터베이스에 연결 (항상 존재)
print("사용 가능한 데이터베이스 목록을 확인합니다...\n")

try:
    conn = psycopg2.connect(
        host=endpoint,
        database="postgres",  # 기본 데이터베이스, DB 이름 설정한 경우 해당 이름으로
        user=username,
        password=password,
        port=5432
    )
    
    cur = conn.cursor()
    
    # 모든 데이터베이스 조회
    cur.execute("""
        SELECT datname 
        FROM pg_database 
        WHERE datistemplate = false
        ORDER BY datname;
    """)
    
    databases = cur.fetchall()
    
    print("사용 가능한 데이터베이스:")
    print("-" * 40)
    for db in databases:
        print(f"  - {db[0]}")
    
    print("\n연결 성공!")
    
    cur.close()
    conn.close()
    
except Exception as e:
    print(f"오류 발생: {e}")
