import psycopg2
from psycopg2.extensions import ISOLATION_LEVEL_AUTOCOMMIT

endpoint = "mydb-1.xxxxxx.us-east-1.rds.amazonaws.com"
username = "your name"
password = "your password"

print("새 데이터베이스 'mydb-1'을 생성합니다...\n")

try:
    # postgres 데이터베이스에 연결
    conn = psycopg2.connect(
        host=endpoint,
        database="postgres",
        user=username,
        password=password,
        port=5432
    )
    conn.set_isolation_level(ISOLATION_LEVEL_AUTOCOMMIT)
    
    cur = conn.cursor()
    
    # database-1 데이터베이스 생성 (하이픈이 있어서 따옴표 필요)
    print("1. 'database-1' 데이터베이스 생성 중...")
    cur.execute('CREATE DATABASE "database-1";')
    print(" 데이터베이스가 생성되었습니다.")
    
    cur.close()
    conn.close()
    
    # 새로 생성한 database-1에 연결하여 pgvector 설치
    print("\n2. 'database-1'에 pgvector 확장 설치 중...")
    conn2 = psycopg2.connect(
        host=endpoint,
        database="database-1",
        user=username,
        password=password,
        port=5432
    )
    conn2.set_isolation_level(ISOLATION_LEVEL_AUTOCOMMIT)
    
    cur2 = conn2.cursor()
    cur2.execute("CREATE EXTENSION IF NOT EXISTS vector;")
    print("pgvector 확장이 설치되었습니다.")
    
    cur2.close()
    conn2.close()
    
    print("\n모든 작업이 완료되었습니다!")
    print("이제 database='database-1'로 연결할 수 있습니다.")
    
except psycopg2.errors.DuplicateDatabase:
    print("   ℹ 'database-1' 데이터베이스가 이미 존재합니다.")
except Exception as e:
    print(f"오류 발생: {e}")
