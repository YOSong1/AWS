import psycopg
from psycopg.rows import dict_row

# DB 연결 정보 
connection_string = "postgresql://song:YOUR_PASSWORD@mydb-1.xxxxx.ap-northeast-2.rds.amazonaws.com:5432/ragdb"


try:
    # 데이터베이스 연결
    with psycopg.connect(connection_string, row_factory=dict_row) as conn:
        with conn.cursor() as cur:
            
            print("=== 1. 스키마 확인 ===")
            cur.execute("""
                SELECT schema_name FROM information_schema.schemata 
                WHERE schema_name = 'bedrock_integration'
            """)
            print(cur.fetchall())
            
            print("\n=== 2. 테이블 확인 ===")
            cur.execute("""
                SELECT table_name FROM information_schema.tables 
                WHERE table_schema = 'bedrock_integration'
            """)
            print(cur.fetchall())
            
            print("\n=== 3. 테이블 구조 확인 ===")
            cur.execute("""
                SELECT column_name, data_type 
                FROM information_schema.columns 
                WHERE table_schema = 'bedrock_integration' AND table_name = 'bedrock_kb'
            """)
            for row in cur.fetchall():
                print(f"  {row['column_name']}: {row['data_type']}")
            
            print("\n=== 4. 현재 데이터 개수 ===")
            cur.execute("SELECT COUNT(*) as count FROM bedrock_integration.bedrock_kb")
            result = cur.fetchone()
            print(f"  총 {result['count']}개의 레코드")
            
            print("\n=== 5. 샘플 데이터 조회 (최대 5개) ===")
            cur.execute("""
                SELECT id, chunks, metadata 
                FROM bedrock_integration.bedrock_kb 
                LIMIT 5
            """)
            for idx, row in enumerate(cur.fetchall(), 1):
                print(f"\n  [{idx}] ID: {row['id']}")
                print(f"      Chunks: {row['chunks'][:100]}...")
                print(f"      Metadata: {row['metadata']}")
            
except Exception as e:
    print(f"오류 발생: {e}")
