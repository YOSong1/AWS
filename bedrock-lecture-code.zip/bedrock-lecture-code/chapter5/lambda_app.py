# lambda_app.py
import os, json
from langchain_aws import ChatBedrock
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser

chat_model_id = os.getenv(
    "BEDROCK_CHAT_MODEL_ID",
    "anthropic.claude-3-haiku-20240307-v1:0",
)

llm = ChatBedrock(
    model_id=chat_model_id,
    region_name=os.getenv("AWS_REGION", "us-east-1"),
    model_kwargs={"temperature": 0.2, "max_tokens": 512},
)

prompt = ChatPromptTemplate.from_messages(
    [
        ("system", "너는 한국어를 잘하는 AI 조교야."),
        ("human", "{question}")
    ]
)
parser = StrOutputParser()
chain = prompt | llm | parser


def lambda_handler(event, context):
    # HTTP 요청이 API Gateway/Function URL을 통해 들어온다고 가정
    body = event.get("body")
    if isinstance(body, str):
        body = json.loads(body or "{}")

    question = body.get("question", "")
    if not question:
        return {
            "statusCode": 400,
            "body": json.dumps({"error": "question is required"})
        }

    answer = chain.invoke({"question": question})

    return {
        "statusCode": 200,
        "headers": {"Content-Type": "application/json; charset=utf-8"},
        "body": json.dumps({"answer": answer}, ensure_ascii=False),
    }
