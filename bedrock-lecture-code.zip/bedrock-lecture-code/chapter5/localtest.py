import requests

LAMBDA_URL = "https://fmah3ubzthfgav4oospzf5jgay0fkwct.lambda-url.ap-northeast-2.on.aws/"

resp = requests.post(
    LAMBDA_URL,
    json={"question": "Bedrock이 뭐야?"}
)

data = resp.json()
print("답변:", data["answer"])




