# lambda_large_app.py
# S3를 활용한 대용량 Lambda 함수 (LangChain + Boto3 + Numpy + Pandas)
import os
import json
import boto3
from datetime import datetime
import numpy as np
from io import BytesIO, StringIO

from langchain_aws import ChatBedrock
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser

# AWS 클라이언트 초기화
s3_client = boto3.client('s3')
S3_BUCKET = os.getenv("S3_BUCKET_NAME", "my-lambda-data-bucket")

# Bedrock 모델 설정
chat_model_id = os.getenv(
    "BEDROCK_CHAT_MODEL_ID",
    "anthropic.claude-3-haiku-20240307-v1:0",
)

llm = ChatBedrock(
    model_id=chat_model_id,
    region_name=os.getenv("AWS_REGION", "us-east-1"),
    model_kwargs={"temperature": 0.2, "max_tokens": 1024},
)

prompt = ChatPromptTemplate.from_messages(
    [
        ("system", "너는 한국어를 잘하고 데이터 분석도 할 수 있는 AI 조교야. 사용자의 질문에 답변하고, 필요시 S3에 저장된 데이터를 분석해줄 수 있어."),
        ("human", "{question}")
    ]
)
parser = StrOutputParser()
chain = prompt | llm | parser


def save_to_s3(content, key):
    """S3에 콘텐츠 저장"""
    try:
        if isinstance(content, str):
            content = content.encode('utf-8')
        s3_client.put_object(Bucket=S3_BUCKET, Key=key, Body=content)
        return f"s3://{S3_BUCKET}/{key}"
    except Exception as e:
        return f"S3 저장 실패: {str(e)}"


def read_from_s3(key):
    """S3에서 콘텐츠 읽기"""
    try:
        response = s3_client.get_object(Bucket=S3_BUCKET, Key=key)
        content = response['Body'].read()
        return content.decode('utf-8')
    except Exception as e:
        return f"S3 읽기 실패: {str(e)}"


def generate_sample_data():
    """NumPy를 사용한 샘플 데이터 생성"""
    data = {
        "random_numbers": np.random.rand(10).tolist(),
        "statistics": {
            "mean": float(np.mean(np.random.rand(100))),
            "std": float(np.std(np.random.rand(100))),
            "sum": float(np.sum(np.random.rand(100)))
        },
        "matrix": np.eye(3).tolist(),
        "timestamp": datetime.now().isoformat()
    }
    return data


def process_ai_question(question):
    """AI 모델을 사용하여 질문 처리"""
    answer = chain.invoke({"question": question})
    return answer


def lambda_handler(event, context):
    """
    Lambda 핸들러 - 다양한 작업 수행
    - AI 질문 답변
    - S3 데이터 저장/읽기
    - NumPy를 사용한 데이터 생성 및 분석
    """
    try:
        # HTTP 요청 파싱
        body = event.get("body")
        if isinstance(body, str):
            body = json.loads(body or "{}")
        
        action = body.get("action", "ask")  # ask, save, read, generate
        
        # 1. AI 질문 답변 (기본)
        if action == "ask":
            question = body.get("question", "")
            if not question:
                return {
                    "statusCode": 400,
                    "body": json.dumps({"error": "question is required"}, ensure_ascii=False)
                }
            
            answer = process_ai_question(question)
            
            # 답변을 S3에 저장 (선택사항)
            save_history = body.get("save_history", False)
            s3_path = None
            if save_history:
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                key = f"conversations/{timestamp}.json"
                history = json.dumps({
                    "question": question,
                    "answer": answer,
                    "timestamp": timestamp
                }, ensure_ascii=False)
                s3_path = save_to_s3(history, key)
            
            return {
                "statusCode": 200,
                "headers": {"Content-Type": "application/json; charset=utf-8"},
                "body": json.dumps({
                    "answer": answer,
                    "s3_path": s3_path
                }, ensure_ascii=False),
            }
        
        # 2. 데이터 생성 및 S3 저장
        elif action == "generate":
            data = generate_sample_data()
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            key = f"generated_data/{timestamp}.json"
            s3_path = save_to_s3(json.dumps(data, ensure_ascii=False), key)
            
            return {
                "statusCode": 200,
                "headers": {"Content-Type": "application/json; charset=utf-8"},
                "body": json.dumps({
                    "message": "데이터가 생성되어 S3에 저장되었습니다",
                    "data": data,
                    "s3_path": s3_path
                }, ensure_ascii=False),
            }
        
        # 3. S3에서 데이터 읽기
        elif action == "read":
            key = body.get("key", "")
            if not key:
                return {
                    "statusCode": 400,
                    "body": json.dumps({"error": "key is required"}, ensure_ascii=False)
                }
            
            content = read_from_s3(key)
            
            return {
                "statusCode": 200,
                "headers": {"Content-Type": "application/json; charset=utf-8"},
                "body": json.dumps({
                    "content": content,
                    "key": key
                }, ensure_ascii=False),
            }
        
        # 4. S3에 데이터 저장
        elif action == "save":
            content = body.get("content", "")
            key = body.get("key", "")
            if not content or not key:
                return {
                    "statusCode": 400,
                    "body": json.dumps({"error": "content and key are required"}, ensure_ascii=False)
                }
            
            s3_path = save_to_s3(content, key)
            
            return {
                "statusCode": 200,
                "headers": {"Content-Type": "application/json; charset=utf-8"},
                "body": json.dumps({
                    "message": "데이터가 S3에 저장되었습니다",
                    "s3_path": s3_path
                }, ensure_ascii=False),
            }
        
        else:
            return {
                "statusCode": 400,
                "body": json.dumps({
                    "error": "Invalid action. Use: ask, generate, read, or save"
                }, ensure_ascii=False)
            }
    
    except Exception as e:
        return {
            "statusCode": 500,
            "headers": {"Content-Type": "application/json; charset=utf-8"},
            "body": json.dumps({
                "error": str(e)
            }, ensure_ascii=False),
        }
