import os
import sys
import json
from dotenv import load_dotenv

import boto3
from botocore.exceptions import ClientError

load_dotenv()  # .env 읽기 (.env가 없어도 무시됨)

# 1) 모델/리전 설정
MODEL_ID = os.getenv("BEDROCK_CHAT_MODEL_ID", "amazon.titan-text-express-v1")
REGION = os.getenv("AWS_DEFAULT_REGION") or os.getenv("AWS_REGION", "us-east-1")

# 2) Bedrock Runtime 클라이언트 생성
bedrock = boto3.client("bedrock-runtime", region_name=REGION)


SYSTEM_PROMPT = os.getenv(
    "SYSTEM_PROMPT",
    "너는 한국어를 잘하는 시니어 백엔드 & 클라우드 개발자야. 짧고 명확하게 설명해줘.",
)


def ask_once(question: str) -> str:
    """Bedrock converse API로 한 번 질문하고 문자열 답변 반환"""
    try:
        combined = f"{SYSTEM_PROMPT}\n\n질문: {question}"
        response = bedrock.converse(
            modelId=MODEL_ID,
            messages=[
                {"role": "user", "content": [{"text": combined}]},
            ],
            inferenceConfig={
                "maxTokens": 512,
                "temperature": 0.2,
                "topP": 0.9,
            },
        )

        # 출력 텍스트 추출
        output_message = response["output"]["message"]
        parts = output_message.get("content", [])
        texts = [p.get("text", "") for p in parts if isinstance(p, dict)]
        return "".join(texts).strip()

    except ClientError as e:
        # Anthropic 승인 미완료 등 케이스 안내
        if "use case" in str(e).lower() or "Model use case details" in str(e):
            return (
                "모델 사용 승인(Use case details)이 필요합니다. "
                "BEDROCK_CHAT_MODEL_ID를 승인 불필요한 Amazon Titan으로 설정하거나, 승인 후 다시 시도하세요."
            )
        raise


if __name__ == "__main__":

    while True:
        q = input("\n질문(exit 입력 시 종료): ").strip()
        if not q or q.lower() == "exit":
            break

        try:
            answer = ask_once(q)
            print("\n[모델 답변]")
            print(answer)
        except ClientError as e:
            print("Bedrock 호출 중 오류가 발생했습니다.")
            print(str(e))
        except Exception as e:
            print("예상하지 못한 오류:", str(e))
