import boto3


bedrock = boto3.client("bedrock-runtime")

def ask_bedrock(prompt: str) -> str:

    response = bedrock.converse(
        modelId="amazon.titan-text-express-v1", 
        messages=[
            {
                "role": "user",
                "content": [{"text": prompt}],
            }
        ],
        inferenceConfig={
            "maxTokens": 100,        
        },
    )

    # 출력 텍스트 추출
    output_message = response["output"]["message"]
    text = output_message["content"][0]["text"]
    return text


if __name__ == "__main__":
    user_prompt = "VS Code에서 Bedrock를 설명해주세요."
    answer = ask_bedrock(user_prompt)
    print("Bedrock 응답:", answer)
