import os
import json
import requests
from typing import List, Dict, Tuple, Optional
from openai import OpenAI
from dotenv import load_dotenv

# 환경 변수 로드
load_dotenv()

# API 키들 설정
OPENAI_API_KEY = os.environ["OPENAI_API_KEY2"]
GOOGLE_API_KEY = os.environ["GOOGLE_API_KEY2"]
GOOGLE_CSE_ID = os.environ["GOOGLE_CSE_ID2"]

# OpenAI 클라이언트 생성
client = OpenAI(api_key=OPENAI_API_KEY)

# Google Custom Search API 엔드포인트
GOOGLE_SEARCH_ENDPOINT = "https://www.googleapis.com/customsearch/v1"

def google_search(query: str, num_results: int = 10) -> Tuple[List[Dict], Optional[str]]:

    # 검색 파라미터 설정
    params = {
        "key": GOOGLE_API_KEY,
        "cx": GOOGLE_CSE_ID,
        "q": query,
        "num": min(num_results, 10),  # Google API는 최대 10개까지
        "hl": "ko",  # 한국어 결과 우선
    }
    
    try:
        # Google API 호출
        response = requests.get(GOOGLE_SEARCH_ENDPOINT, params=params, timeout=15)
        
        if response.status_code == 200:
            data = response.json()
            items = data.get("items", [])
            
            # 검색 결과 정리
            results = []
            for item in items:
                results.append({
                    "title": item.get("title", ""),
                    "link": item.get("link", ""),
                    "snippet": item.get("snippet", ""),
                    "displayLink": item.get("displayLink", "")
                })
            
            return results, None
        else:
            return [], f"Google API 오류: {response.status_code}"
            
    except Exception as e:
        return [], f"검색 중 오류: {e}"

def build_search_context(search_results: List[Dict]) -> str:

    if not search_results:
        return "검색 결과가 없습니다."
    
    context_parts = []
    
    for i, result in enumerate(search_results, 1):
        title = result.get("title", "제목 없음")
        snippet = result.get("snippet", "내용 없음")
        link = result.get("link", "")
        
        # 각 검색 결과를 번호와 함께 정리
        context_part = f"""[{i}] {title}
내용: {snippet}
링크: {link}"""
        
        context_parts.append(context_part)
    
    return "\n\n".join(context_parts)

def ask_gpt_with_context(question: str, search_context: str) -> str:
        
    print(question)
    print()
    print(search_context)
    prompt = f"""

[질문]
{question}
[웹 검색 결과]
{search_context}


웹 검색 결과를 바탕으로 사용자의 질문에 정확하고 유용한 답변을 만들어주세요.
검색 결과에 언급되지 않는 내용은 넣지 마세요. 추측성 답을 사용하지 마세요.


각 정보의 출처를 [번호] 형태로 표시하세요. 
 - [번호] 표시 된 부분에 참고한 링크를 클릭할 수 있도록 하세요. 
 - 세부 정보 확인을 할 수 있도록 링크를 추가하세요.
"""
    
    try:
        response = client.chat.completions.create(
            model="gpt-4o",
            messages=[{"role": "user", "content": prompt}],
            max_tokens=800,
            temperature=0.3
        )
        return response.choices[0].message.content.strip()
    except Exception as e:
        return f"GPT 응답 생성 중 오류: {e}"



print("종료하려면 'quit' 입력\n")

while True:
    # 사용자 질문 입력
    question = input("질문: ").strip()
    
    if not question:
        continue
        
    if question.lower() in ("quit", "exit", "종료"):
        print("프로그램을 종료합니다.")
        break
    
    print(f"\n[1단계] 웹에서 '{question}' 관련 정보 검색 중...")
    
    # 1단계: 웹 검색
    search_results, error = google_search(question, num_results=15)
    
    if error:
        print(f"검색 실패: {error}")
        continue
    
    if not search_results:
        print("검색 결과가 없습니다.")
        continue
    
    print(f"{len(search_results)}개의 검색 결과를 찾았습니다.")
    
    # 2단계: 검색 결과를 컨텍스트로 변환
    print("[2단계] 검색 결과를 GPT가 이해할 수 있는 형태로 변환 중...")
    context = build_search_context(search_results)
    
    # 3단계: GPT에게 검색 결과와 함께 질문
    print("[3단계] GPT가 검색 결과를 바탕으로 답변 생성 중...")
    answer = ask_gpt_with_context(question, context)
    
    # 결과 출력
    print("\n=== 답변 ===\n")
    print(answer)
    print("\n=============\n")
    