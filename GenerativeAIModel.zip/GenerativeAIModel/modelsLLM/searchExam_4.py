import os
import json
import requests
from typing import List, Dict, Tuple, Optional
from openai import OpenAI
from dotenv import load_dotenv
from datetime import datetime
from zoneinfo import ZoneInfo

# --- 오늘 날짜/요일 구하기 ---
def now_kst() -> datetime:
    return datetime.now(ZoneInfo("Asia/Seoul"))

WEEKDAY_KO = ["월", "화", "수", "목", "금", "토", "일"]

def today_context_strings(dt: datetime) -> Dict[str, str]:
    return {
        "iso_date": dt.strftime("%Y-%m-%d"),        # YYYY-MM-DD
        "weekday_ko": WEEKDAY_KO[dt.weekday()],     # 요일 (월~일)
        "iso_datetime": dt.isoformat(),             # 전체 ISO 문자열
        "tz": "Asia/Seoul (+09:00)",
    }

# --- 질문에 따른 날짜 제한 처리 ---
def detect_date_restrict(question: str) -> Dict[str, Optional[str]]:
    q = question.lower()
    restrict, sort = None, None
    if any(kw in q for kw in ["오늘", "금일", "현재", "지금", "속보"]):
        restrict, sort = "d1", "date"   # 지난 24시간
    elif "어제" in q:
        restrict, sort = "d2", "date"
    elif "이번 주" in q or "금주" in q:
        restrict, sort = "w1", "date"
    elif "지난주" in q or "저번 주" in q:
        restrict, sort = "w2", "date"
    elif "이번 달" in q or "금월" in q:
        restrict, sort = "m1", "date"
    elif "지난달" in q:
        restrict, sort = "m2", "date"
    return {"dateRestrict": restrict, "sort": sort}


load_dotenv()

OPENAI_API_KEY = os.environ["OPENAI_API_KEY2"]
GOOGLE_API_KEY = os.environ["GOOGLE_API_KEY2"]
GOOGLE_CSE_ID  = os.environ["GOOGLE_CSE_ID2"]

client = OpenAI(api_key=OPENAI_API_KEY)
GOOGLE_SEARCH_ENDPOINT = "https://www.googleapis.com/customsearch/v1"

def google_search(query: str, num_results: int = 10, question_text: str = "") -> Tuple[List[Dict], Optional[str]]:
    restrict_info = detect_date_restrict(question_text or query)

    params = {
        "key": GOOGLE_API_KEY,
        "cx": GOOGLE_CSE_ID,
        "q": query,
        "num": min(num_results, 10),
        "hl": "ko",
    }
    if restrict_info["dateRestrict"]:
        params["dateRestrict"] = restrict_info["dateRestrict"]
    if restrict_info["sort"]:
        params["sort"] = restrict_info["sort"]

    try:
        response = requests.get(GOOGLE_SEARCH_ENDPOINT, params=params, timeout=15)
        if response.status_code == 200:
            items = response.json().get("items", [])
            return [
                {
                    "title": item.get("title", ""),
                    "link": item.get("link", ""),
                    "snippet": item.get("snippet", ""),
                    "displayLink": item.get("displayLink", "")
                } for item in items
            ], None
        else:
            return [], f"Google API 오류: {response.status_code}"
    except Exception as e:
        return [], f"검색 중 오류: {e}"

def build_search_context(search_results: List[Dict]) -> str:
    if not search_results:
        return "검색 결과가 없습니다."
    return "\n\n".join(
        f"[{i}] {r['title']}\n내용: {r['snippet']}\n링크: {r['link']}"
        for i, r in enumerate(search_results, 1)
    )

def ask_gpt_with_context(question: str, search_context: str) -> str:
    now = now_kst()
    ctx = today_context_strings(now)

    system_msg = (
        "당신은 한국(Asia/Seoul) 기준 뉴스/사실 보조자입니다. "
        f"현재 날짜와 시간은 {ctx['iso_datetime']} ({ctx['weekday_ko']}요일, {ctx['tz']}) 입니다. "
        "사용자가 '오늘', '어제', '이번 주' 같은 표현을 쓰면 이 시간을 기준으로 해석하세요. "
        "출처는 반드시 [번호](링크) 형식으로 표시하세요."
    )

    prompt = f"""
[질문]
{question}

[오늘 기준 정보]
- 오늘 날짜: {ctx['iso_date']} ({ctx['weekday_ko']}요일)

[웹 검색 결과]
{search_context}

웹 검색 결과를 바탕으로 사용자의 질문에 정확하고 유용한 답변을 만들어주세요.
검색 결과에 언급되지 않는 내용은 넣지 마세요. 추측성 답을 사용하지 마세요.


각 정보의 출처를 [번호] 형태로 표시하세요. 
 - [번호] 표시 된 부분에 참고한 링크를 클릭할 수 있도록 하세요. 
 - 세부 정보 확인을 할 수 있도록 링크를 추가하세요.
"""
    
    response = client.chat.completions.create(
        model="gpt-4o",
        messages=[
            {"role": "system", "content": system_msg},
            {"role": "user", "content": prompt}
        ],
        max_tokens=800,
        temperature=0.3
    )
    return response.choices[0].message.content.strip()

print("종료하려면 'quit' 입력\n")

while True:
    question = input("질문: ").strip()
    if not question:
        continue
    if question.lower() in ("quit", "exit", "종료"):
        print("프로그램을 종료합니다.")
        break

    now = now_kst()
    ctx = today_context_strings(now)
    query_with_date = f"{question} {ctx['iso_date']} {ctx['weekday_ko']}요일"

    print(f"\n[1단계] 웹에서 '{question}' 검색 중...")
    search_results, error = google_search(query_with_date, num_results=15, question_text=question)
    if error:
        print(f"검색 실패: {error}")
        continue
    if not search_results:
        print("검색 결과가 없습니다.")
        continue

    print(f"{len(search_results)}개의 검색 결과를 찾았습니다.")
    context = build_search_context(search_results)

    print("[2단계] GPT가 답변 생성 중...")
    answer = ask_gpt_with_context(question, context)

    print("\n=== 답변 ===\n")
    print(answer)
    print("\n=============\n")



'''
각 정보의 출처를 [번호] 형태로 표시하세요. 
 - [번호] 표시 된 부분에 참고한 링크를 클릭할 수 있도록 하세요. 
 - 이 때 번호를 클릭하면 링크가 열리게하고 URL은 화면상에 보이지 않도록 처리하세요.
 - [1] 만 표시하고 실제 링크는 번호 1 부분에 <a href=....>[1]</a> 형식이 되도록 하세요.
 
"""
'''