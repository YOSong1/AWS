import os
from openai import OpenAI
from dotenv import load_dotenv

# 환경 변수 로드
load_dotenv()

# OpenAI API 키 설정
OPENAI_API_KEY = os.environ["OPENAI_API_KEY2"]

# OpenAI 클라이언트 생성
client = OpenAI(api_key=OPENAI_API_KEY)

def ask_gpt_basic(question: str) -> str:
   
    try:
        response = client.chat.completions.create(
            model="gpt-4o",
            messages=[{"role": "user", "content": question}],
            max_tokens=500,
            temperature=0.7
        )
        return response.choices[0].message.content.strip()
    except Exception as e:
        return f"오류 발생: {e}"

# 프로그램 시작
print("종료하려면 'quit' 입력\n")

while True:
    # 사용자 질문 입력
    question = input("질문: ").strip()
    
    if not question:
        continue
        
    if question.lower() in ("quit", "exit", "종료"):
        print("프로그램을 종료합니다.")
        break
    
    print("\n[GPT] 답변 생성 중...")
    
    # GPT 응답 생성
    answer = ask_gpt_basic(question)
    
    print("\n=== 답변 ===\n")
    print(answer)
    print("\n=============\n")
    
   
